// Modulo 27 - parte del sistema FaceWork
