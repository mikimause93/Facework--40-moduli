// Modulo 32 - parte del sistema FaceWork
